def add(first, second):
    return first + second

print(add(5, 10))
print(add('abcd', 'efgh'))
print(add(5, 'efgh'))
print(add(print, len))


# pycharm
